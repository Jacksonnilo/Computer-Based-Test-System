<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Computer-Based Test</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
    <header>
        <div class="container">
            <h1>Computer-Based Test</h1>
            <a href="login.php" class="login-button">Login</a>
        </div>
    </header>

    <section class="login">
        <div class="container">
            <h2>Login</h2>
            <form method="post" action="process_login.php">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="login-button">Login</button>
            </form>
        </div>
    </section>
</body>
</html>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    
    header {
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 20px 0;
    }
    
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    h1 {
        margin: 0;
    }
    
    .login-button {
        display: inline-block;
        background-color: #333;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        margin-left: 20px;
    }
    
    .login-button:hover {
        background-color: #555;
    }
    
    .hero {
        background-image: url('background.jpg'); /* Add a background image */
        background-size: cover;
        background-position: center;
        color: #fff;
        text-align: center;
        padding: 100px 0;
    }
    
    .container h2 {
        font-size: 36px;
    }
    
    .container p {
        font-size: 18px;
    }
    
    /* Add more CSS styles as needed */
    
</style>
